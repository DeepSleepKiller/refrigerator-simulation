#ifndef __MYAT24C02_H
#define __MYAT24C02_H
void AT24C02_WriteReg(uint8_t RegAddress, uint8_t Data);
uint8_t AT24C02_ReadReg(uint8_t RegAddress);
void AT24C02_Init(void);
void AT24C02_Task(void);
void AT24C02_WriteAsync(uint8_t RegAddress, uint8_t Data);
#endif
