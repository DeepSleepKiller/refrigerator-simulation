#ifndef __BUZZER_H
#define __BUZZER_H
typedef enum {
    BUZZER_STATE_START_WAIT,    	// 门开关松开后开始计时
    BUZZER_STATE_IDLE,            // 空闲，等待门开关松开
    BUZZER_STATE_FLASH   		    // 超时，开始间歇鸣响
} Buzzer_state_t;
void Buzzer_Init(Buzzer_state_t* state);
void Buzzer_ON(void);
void Buzzer_OFF(void);
void Buzzer_Turn(void);
void Buzzer_Process(Buzzer_state_t* state);

#endif
