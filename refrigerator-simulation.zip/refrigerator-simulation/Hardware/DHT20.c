#include "stm32f10x.h"                  // Device header
#include "MyI2C.h"
#include "DHT20.h"
#include "Delay.h"
#include "Timer.h"
#define DHT20_ADDRESS					0x38		//DHT20的I2C从机地址
#define DHT20_ADDRESS_W					0x70		//DHT20的I2C从机地址写
#define DHT20_ADDRESS_R					0x71		//DHT20的I2C从机地址读
#define DHT20_DELAY_POWER_ON_WAIT		 100		//DHT20上电后等待100ms
#define DHT20_DELAY_MEASURING_BEFORE	  10		//DHT20测量前等待10ms
#define DHT20_DELAY_MEASURING_WAIT		  80		//DHT20测量后等待80ms

/**
  * 函    数：DHT20读状态
  * 参    数：
  * 返 回 值：DHT20的状态字节
  * 说    明：根据手册，需要向DHT20模块发送命令，0x71(读取命令)，然后接受返回得数据
  */
uint8_t DHT20_GetState(void)
{
	uint8_t Data;
	MyI2C_Start();						//I2C起始
	MyI2C_SendByte(DHT20_ADDRESS_R);	//发送从机地址，读写位为1，表示即将读出
	MyI2C_ReceiveAck();
	Data = MyI2C_ReceiveByte();			//接收指定寄存器的数据
	MyI2C_SendAck(1);					//发送应答，给从机非应答，终止从机的数据输出
	MyI2C_Stop();						//I2C终止
	return Data;
}

/**
  * 函    数：DHT20初始化
  * 参    数：
  * 返 回 值：
  * 说    明：包含了I2C的初始化，以及读取状态位
  */
//void DHT20_Init(void)
//{
//	MyI2C_Init();
//	Delay_ms(DHT20_Delay_Start);				//上电等待100ms
//	DHT20_GetState();							//得状态
//	Delay_ms(DHT20_Delay_MeasureStart);			//触发测量前等待10ms
//	
//}

/**
  * 函    数：DHT20触发测量
  * 参    数：
  * 返 回 值：空
  * 说    明：根据手册，需要向DHT20模块发送三个字节，依次是0xAC 0x33 0x00，但是发送字节前应该发送写入命令，即0x70
  */
void DHT20_MeasureStart(void)
{
	MyI2C_Start();						//I2C起始
	MyI2C_SendByte(DHT20_ADDRESS_W);	//发送写入命令，读写位为0，表示即将写入（命令字节）
	MyI2C_ReceiveAck();					//接收应答
	MyI2C_SendByte(0xAC);				//手册固定值0xAC
	MyI2C_ReceiveAck();					//接收应答	
	MyI2C_SendByte(0x33);				//手册固定值
	MyI2C_ReceiveAck();					//接收应答
	MyI2C_SendByte(0x00);				//手册固定值	
	MyI2C_ReceiveAck();					//接收应答
	MyI2C_Stop();						//I2C终止
}

/**
  * 函    数：DHT20读测量数据
  * 参    数：uint8_t 数组指针
  * 返 回 值：
  * 说    明：根据手册，需要向DHT20模块发送读命令（0x71），然后接收7个字节，1状态字节+2.5湿度数据+2.5温度数据+1CRC校验
  */
void DHT20_ReadDatas(uint8_t* Data, uint32_t* humid, uint32_t* temper)
{
	uint8_t i = 0;
	MyI2C_Start();														//I2C起始
	MyI2C_SendByte(DHT20_ADDRESS_R);									//发送从机地址，读写位为1，表示即将读出
	MyI2C_ReceiveAck();													//接收应答
	for( i = 0; i < 7; i++)								
	{								
		Data[i] = MyI2C_ReceiveByte();									//接收指定寄存器的数据
		if(i == 6)								
		{								
			MyI2C_SendAck(1);											//发送应答，给从机非应答，终止从机的数据输出				
		}								
		else								
		{								
			MyI2C_SendAck(0);											//发送应答，给从机应答，继续接收从机的数据输出					
		}

	}

	MyI2C_Stop();						//I2C终止
	*humid = (((uint32_t)Data[1] << 12) | ((uint32_t)Data[2] << 4) | ((uint32_t)Data[3] & 0xF0) >> 4); //最高位数据
	*temper = (((uint32_t)Data[3] & 0x0F) << 16) | ((uint32_t)Data[4] << 8) | Data[5];					//
	*humid = *humid*1000.0/1024/1024;																	//
	*temper = *temper*100.0*200/1024/1024-5000;
}

/**
  * 函    数：DHT20读指定长度数据
  * 参    数：uint8_t 数组指针，uint8_t 数组长度
  * 返 回 值：_Bool 如果返回的数组为空，返回0，代表读取失败，否则返回1；
  * 说    明：根据手册，需要向DHT20模块发送读命令（0x71），然后接收Length个字节
  */
_Bool DHT20_Read_Length_Datas(uint8_t* Data, uint8_t Length)
{
	MyI2C_Start();														//I2C起始
	MyI2C_SendByte(DHT20_ADDRESS_R);									//发送从机地址，读写位为1，表示即将读出
	MyI2C_ReceiveAck();													//接收应答
	for (uint8_t i = 0; i < Length; i++)								
	{								
		Data[i] = MyI2C_ReceiveByte();									//接收指定寄存器的数据
		if (i == (Length - 1))								
		{								
			MyI2C_SendAck(1);											//发送应答，给从机非应答，终止从机的数据输出				
		}								
		else								
		{								
			MyI2C_SendAck(0);											//发送应答，给从机应答，继续接收从机的数据输出					
		}

	}
	MyI2C_Stop();						//I2C终止
	if (Data[0] == 0)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

/**
  * 函    数：DHT20解析数据
  * 参    数：DHT20_sensor_t* sensor，传感器文本
  * 返 回 值：空
  * 说    明：将sensor中的原始数据转化为温度和湿度（为了方便OLED显示，都扩大了100倍），并保存到sensor结构体中
  */

void DHT20_Data_Parse(DHT20_sensor_t* sensor)
{
	float humidity, temperature;
	
	humidity = (((uint32_t)sensor->raw_data[1] << 12) | 
						((uint32_t)sensor->raw_data[2] << 4) | 
						((uint32_t)sensor->raw_data[3] & 0xF0) >> 4);
	temperature = (((uint32_t)sensor->raw_data[3] & 0x0F) << 16) | 
							((uint32_t)sensor->raw_data[4] << 8) | 
								sensor->raw_data[5];
	
	sensor->humidity = humidity*1000.0/1024/1024;																	//
	sensor->temperature = temperature*200/1024/1024-50;
}
/**
  * 函    数：**核心**  DHT20状态机
  * 参    数：DHT20_sensor_t* sensor，传感器文本
  * 返 回 值：空
   * 说    明：此函数需要放到main函数的while中不断轮询，以查询当前状态并执行状态下的操作
	非阻塞式等待就是靠状态机中不断获取当前时间与状态开始时间进行比较，差（等待时间）满足就转入下一状态，或等待主函数读取函数
  */

void DHT20_Process(DHT20_sensor_t* sensor) 
{
    uint32_t current_time = Timer_Get_System_tick_ms();

    switch(sensor->state) {
        case DHT20_STATE_POWER_ON_WAIT:
            // 检查是否等待够了足够的时间（例如100ms）,时间在DHT20_Init中设置
            if ((current_time - sensor->wait_start_time) >= sensor->wait_duration) 
			{
                // 等待时间到，切换到空闲状态
                sensor->state = DHT20_STATE_IDLE;
            }
            break;

        case DHT20_STATE_IDLE:
            // 什么都不做，等待主程序调用触发函数
            // 触发后状态会变为 DHT20_STATE_TRIGGERED
            break;

        case DHT20_STATE_TRIGGERED:
            // 刚触发测量，发送触发命令后立即进入等待状态
            DHT20_MeasureStart(); // 发送DHT20触发命令函数
            sensor->wait_start_time = current_time;
            sensor->wait_duration = DHT20_DELAY_MEASURING_WAIT; // DHT20测量大约需要80ms
            sensor->state = DHT20_STATE_MEASURING_WAIT;
            break;

        case DHT20_STATE_MEASURING_WAIT:
            // 等待测量完成
            if ((current_time - sensor->wait_start_time) >= sensor->wait_duration) 
			{
                // 等待时间到，意味着测量完成，切换到读取状态
                sensor->state = DHT20_STATE_READING;
            }
            break;

        case DHT20_STATE_READING:
            // 从I2C读取6字节数据+1字节CRC
            if (DHT20_Read_Length_Datas(sensor->raw_data, 7)) // I2C读取函数
			{ 
                    DHT20_Data_Parse(sensor);				 // 数据解析函数
                    sensor->state = DHT20_STATE_DATA_READY;
          
            }
			else
			{
                    sensor->state = DHT20_STATE_ERROR;		// 读取数据失败

			}
            break;

        case DHT20_STATE_DATA_READY:
            // 数据已经就绪，保持这个状态直到主程序取走数据
            // 主程序取走数据后，可以手动将其设回 IDLE 状态
            break;

        case DHT20_STATE_ERROR:
            // 处理错误，例如记录日志，之后可以尝试自动恢复或等待外部复位
            // 简单的处理：等待一段时间后回到IDLE
            if ((current_time - sensor->wait_start_time) >= 2000) { // 2秒后重置
                sensor->state = DHT20_STATE_IDLE;
            }
            break;

        default:
            sensor->state = DHT20_STATE_ERROR;
            break;
    }
}

/**
  * 函    数：DHT20初始化
  * 参    数：DHT20_sensor_t* sensor，传感器文本
  * 返 回 值：空
* 说    明：包含了I2C的初始化，将状态机设定为初始上电状态，获取当前时间戳，然后设置上电等待时间
  */
void DHT20_Init(DHT20_sensor_t* sensor) 
{
	MyI2C_Init();
    sensor->state = DHT20_STATE_POWER_ON_WAIT;
    sensor->wait_start_time = Timer_Get_System_tick_ms();
    sensor->wait_duration = DHT20_DELAY_POWER_ON_WAIT; // 上电后等待100ms
}
/**
  * 函    数：DHT20触发测量
  * 参    数：DHT20_sensor_t* sensor，传感器文本
  * 返 回 值：空
* 说    明：只有在空闲状态下，才会触发，将状态调整为开始触发，否则一直保持空闲状态
  */
void DHT20_Trigger_Measurement(DHT20_sensor_t* sensor) 
{
    // 只有在空闲状态下才允许触发
    if (sensor->state == DHT20_STATE_IDLE) {
        sensor->state = DHT20_STATE_TRIGGERED;
    }
}

/**
  * 函    数：DHT20获取数据
  * 参    数：DHT20_sensor_t* sensor，传感器文本；temp，待赋值的温度参数；hum，待赋值的湿度参数
  * 返 回 值：_Bool，1或0,代表程序运行是否成功
* 说    明：数据准备好状态下才可读取，将sensor文本中的参数传递给主函数中的temp和hum变量，并重置状态机
  */
_Bool DHT20_Get_Data(DHT20_sensor_t* sensor, float* temp, float* hum) 
{
    if (sensor->state == DHT20_STATE_DATA_READY) 
	{
        *temp = sensor->temperature;
        *hum = sensor->humidity;
        sensor->state = DHT20_STATE_IDLE; // 取走数据后重置状态机
        return 1;
    }
    return 0;
}
