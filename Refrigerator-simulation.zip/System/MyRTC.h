#ifndef __MYRTC_H
#define __MYRTC_H
#include <time.h>
extern uint16_t MyRTC_Time[];

void MyRTC_Init(void);
void MyRTC_SetTime(void);
void MyRTC_ReadTime(void);
void MyRTC_SetCurTime(time_t time_cnt);

#endif
