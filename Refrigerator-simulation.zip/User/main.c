#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Motor.h"
#include "Key.h"
#include "DHT20.h"
#include "MyI2C.h"
#include "Timer.h"
#include "Encoder.h"
#include "LED.h"
#include "Buzzer.h"
#include "AT24C02.h"
#include "Serial.h"
#include "ESP8266_ntp.h"			//需要在源文件里面设置WiFi名称和密码
#include "MyRTC.h"

uint32_t Number;				//计数，用于看程序是否阻塞
DHT20_sensor_t MyDHT20_Sensor;	//存放DHT20传感器所有数据
float tempture_User;			//用户当前设定温度
Buzzer_state_t MyBuzzer_State; //存放蜂鸣器状态
uint32_t Numer_Open_Door = 0;	//用于记录开关门次数
uint32_t LastNumer_Open_Door = 0;	//用于记录开关门次数
uint8_t Open_Door_temp;			//用于判断门打开瞬间
uint32_t Open_Door_timer;		//用于判断记录门开关次数间隔
uint32_t Current_Count;			//用于临时存放当前时间戳
uint8_t AT24C02_Data_Address;	//用于指定存放地址

typedef union {									//定义一个联合体，方便在AT24C02读写32位时间戳
    uint32_t Data32;          // 32 位视角
    uint8_t  Data8[4];       // 字节视角
} U32;

int main(void)
{
	Key_Init();					//门按键初始化
	LED_Init();					//LED初始化
	OLED_Init();				//OLED初始化
	Timer_Init();				//计时器初始化
	DHT20_Init(&MyDHT20_Sensor);//DHT20传感器初始化
	Motor_Init();				//TB6612电机初始化
	Encoder_Init();				//旋转编码器初始化
	Buzzer_Init(&MyBuzzer_State);	//蜂鸣器初始化
	tempture_User = 30;		//用户默认初始温度为28.5度
	Open_Door_timer = System_tick_ms;//用于判断记录门开关次数间隔

	U32 Current_Count;					//定义联合体存储时间戳；
	
	OLED_ShowString(1, 17, "Time:",  OLED_8X16);
	OLED_ShowString(1, 33, "DOOR:",  OLED_8X16);
	OLED_ShowString(48, 1, "℃",  OLED_8X16); 
	OLED_ShowString(112, 1, "℃",  OLED_8X16);
	OLED_ShowString(1, 49, "Open_Num:",  OLED_8X16);

	//ESP8266初始化并获取网络时间戳、存储在RTC时钟里面
	MyRTC_Init();		//RTC初始化
	Serial_Init();		//串口协议初始化
	//启动ESP8266并获取时间戳，时间戳存储在LastEpoch里面
	uint8_t temp_test = ESP8266_InitAndGetTime();
	uint32_t LastEpoch = GetLastEpoch();
	
	while(1)				
	{
		if(LastEpoch > 30000)
		{
			break;									//如果返回时间戳正确，就中止死循环
		}
		else
		{
			temp_test = ESP8266_InitAndGetTime();	//否则重复初始化并获取时间
			LastEpoch = GetLastEpoch();
		}
	}
	
	MyRTC_SetCurTime(LastEpoch);
	
	
	while(1)
	{   
		//展示实时时间戳

		Current_Count.Data32 = RTC_GetCounter();						//临时变量存放当前RTC时间戳
		OLED_Printf(48, 17, OLED_8X16, "%lu", Current_Count);
		//*一、温度、湿度数据获取    *//
		// 1. 处理传感器状态机（非阻塞！）
        DHT20_Process(&MyDHT20_Sensor);
		// 2. 每隔0.5秒触发一次测量
        static uint32_t last_trigger_time = 0;
        if (Timer_Get_System_tick_ms() - last_trigger_time > 500) 
		{
            last_trigger_time = Timer_Get_System_tick_ms();
            DHT20_Trigger_Measurement(&MyDHT20_Sensor);
        }
		// 3. 尝试获取数据，并在OLED屏幕上显示温度
        float temp, hum;
        if (DHT20_Get_Data(&MyDHT20_Sensor, &temp, &hum)) 
		{ 
			OLED_ShowFloatNum(-8, 1, (double)(hum/10.0), 2, 2, OLED_8X16);			//将湿度humid转化为浮点数，并显示
			OLED_ShowString(40, 1, "%",  OLED_8X16);									//
			OLED_ShowFloatNum(1, 1, (double)(temp), 2, 2, OLED_8X16);          //将温度temper转化为浮点数，并显示

			OLED_Update();
        }
		// 在OLED屏幕上实时显示时钟戳和测试是否阻塞的自加Num
		OLED_ShowNum(73, 33, System_tick_ms, 6, OLED_8X16);
//		OLED_ShowNum(56, 17, Number ++, 6, OLED_8X16);
		OLED_Update();
		//*  温度、湿度获取结束   *//
		
		//* 二、通过旋钮编码器设置当前温度 *//
		tempture_User += (0.5 * Encoder_Get());		//获取自上此调用此函数后，旋转编码器的增量值，并将增量值加到用户设定温度上
		if( tempture_User >= 20.0 && tempture_User <= 30)	//将温度范围限定在25~30℃
		{
			OLED_ShowFloatNum(64, 1, (double)(tempture_User), 2, 2 , OLED_8X16);
		}
		tempture_User = tempture_User < 20.0f ? 20.0f :
						tempture_User > 30.0f ? 30.0f : tempture_User;
	

		
		//*  三、直流电机模拟压缩机运转 *//
		float temp_difference = temp + 0.5 - tempture_User; //如果实际温度比设定温度高-0.5℃以上，就启动压缩机
		if (temp_difference <= 0)
		{
			Motor_SetSpeed(0);
		}
		else
		{
			Motor_SetSpeed((uint8_t)(temp_difference*10));
		}
		
		//*  四、门开关控制冰箱内LED灯开关   *//
		if( Key_GetNum() == 1 )								//如果按键导通，就关灯，并将状态显示在OLED屏幕上
		{
			LED1_OFF();
			Open_Door_temp = 1;								//关门就给临时变量赋值状态1
			OLED_ShowString(41, 33, "OFF",  OLED_8X16);
		}
		else												//否则，就开灯，并将状态显示在OLED屏幕上
		{
			if(Open_Door_temp == 1)							//如果是从关门到开门过程，就开门次数+1，且令值临时变量为0，这样开门次数就不会一直加了
			{
				
				Numer_Open_Door++;
//				AT24C02_WriteAsync(0x03, Numer_Open_Door);
//				AT24C02_WriteReg(0x03, Numer_Open_Door);	//如果开门，就将最新的开门次数输入到EEPROM中
				Open_Door_temp = 0;
			}
			LED1_ON();
			
			OLED_ShowString(41, 33, "ON  ",  OLED_8X16);
			
			OLED_ShowNum(73, 49, Numer_Open_Door, 5, OLED_8X16);
		}

		//*  五、门长时间开启报警   *//
		Buzzer_Process(&MyBuzzer_State);					//不断查询状态并执行相应操作
		
		
		//*  六、将门开关时间戳写入到AT24C02中(多个字节连续写，直接用阻塞)
		
		if (LastNumer_Open_Door != Numer_Open_Door)			//如果开关门次数有变化，就把当前时间戳写到ROM里面
		{
			for(uint8_t i = 0; i < 4; i++)
			{
				AT24C02_WriteReg(AT24C02_Data_Address++, Current_Count.Data8[i]);
				Delay_ms(5);
			}
			
			LastNumer_Open_Door = Numer_Open_Door;
		}
		
		
	}
	
	
}

////* 定时器中断函数，可以复制到使用它的地方，目前是每1ms中断一次
void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
	{
		System_tick_ms++;
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	}
}

