#include "stm32f10x.h"                  // Device header
#include "MyI2C.h"

#define AT24C02_ADDRESS		    0x50		//AT24C02的7位I2C从机地址
#define AT24C02_ADDRESS_W		0xA0		//AT24C02的I2C从机地址（写）
#define AT24C02_ADDRESS_R		0xA1		//AT24C02的I2C从机地址（读）

typedef enum {
    AT24C02_IDLE,
    AT24C02_WRITING,
    AT24C02_WAIT_READY
} AT24C02_State_t;

static AT24C02_State_t AT24C02_State = AT24C02_IDLE;
static uint8_t  AT24C02Retry = 0;
static uint8_t AT24C02Addr;
static uint8_t  AT24C02Data;

/* 主循环里(1ms中断)不断调用状态查询，每次只花几微秒 */
void AT24C02_Task(void)        // 1 ms 调用一次即可
{
    switch (AT24C02_State) {
    case AT24C02_IDLE:
        break;

    case AT24C02_WRITING:
		if (AT24C02Retry > 50)					//超时设定。主循环1ms轮询一次，如果大于50ms就退出当前状态
		{
			AT24C02_State = AT24C02_IDLE;
			AT24C02Retry = 0;
			break;
		}
        MyI2C_Start();
        MyI2C_SendByte(0xA0);          // 设备地址
        if (MyI2C_ReceiveAck() == 0) 
		{    // 收到 ACK
            MyI2C_SendByte(AT24C02Addr);
            MyI2C_ReceiveAck();
            MyI2C_SendByte(AT24C02Data);
            MyI2C_ReceiveAck();
            MyI2C_Stop();
            AT24C02_State = AT24C02_WAIT_READY;
            AT24C02Retry = 0;
			
        } 
		else 
		{                     // 设备正忙，下次再试
            MyI2C_Stop();
			AT24C02Retry ++;

			
        }
        break;

    case AT24C02_WAIT_READY:
        if (AT24C02Retry >= 50) {        // 50 ms 超时
            AT24C02_State = AT24C02_IDLE;
            break;
        }
        MyI2C_Start();
        MyI2C_SendByte(0xA0);
        if (MyI2C_ReceiveAck() == 0) {    // ACK → 写完了
            MyI2C_Stop();
            AT24C02_State = AT24C02_IDLE;     // 任务结束
        } else {
            MyI2C_Stop();
            AT24C02Retry++;              // 下次再来
        }
        break;
    }
}

/* 用户接口：触发一次写，立即返回 */
void AT24C02_WriteAsync(uint8_t RegAddress, uint8_t Data)
{
    if (AT24C02_State != AT24C02_IDLE) return;  // 忙，丢弃或缓存
    AT24C02Addr  = RegAddress;
    AT24C02Data  = Data;
    AT24C02_State = AT24C02_WRITING;
}
/**
  * 函    数：AT24C02初始化
  * 参    数：无
  * 返 回 值：无
  */
void AT24C02_Init(void)
{
	MyI2C_Init();									//先初始化底层的I2C
	
}

/**
  * 函    数：AT24C02写寄存器（写之前要触发写）
  * 参    数：RegAddress 寄存器地址，范围：参考0x00~0xFF
  * 参    数：Data 要写入寄存器的数据，范围：0x00~0xFF
  * 返 回 值：无
  */
  
 
void AT24C02_WriteReg(uint8_t RegAddress, uint8_t Data)
{
	MyI2C_Start();						//I2C起始
	MyI2C_SendByte(AT24C02_ADDRESS_W);	//发送从机地址，读写位为0，表示即将写入
	MyI2C_ReceiveAck();					//接收应答
	MyI2C_SendByte(RegAddress);			//发送寄存器地址
	MyI2C_ReceiveAck();					//接收应答
	MyI2C_SendByte(Data);				//发送要写入寄存器的数据
	MyI2C_ReceiveAck();					//接收应答
	MyI2C_Stop();						//I2C终止
}

/**
  * 函    数：AT24C02读寄存器
  * 参    数：RegAddress 寄存器地址，范围：参考MPU6050手册的寄存器描述
  * 返 回 值：读取寄存器的数据，范围：0x00~0xFF
  */
uint8_t AT24C02_ReadReg(uint8_t RegAddress)
{
	uint8_t Data;
	
	MyI2C_Start();						//I2C起始
	MyI2C_SendByte(AT24C02_ADDRESS_W);	//发送从机地址，读写位为0，表示即将写入
	MyI2C_ReceiveAck();					//接收应答
	MyI2C_SendByte(RegAddress);			//发送寄存器地址
	MyI2C_ReceiveAck();					//接收应答
	
	MyI2C_Start();						//I2C重复起始
	MyI2C_SendByte(AT24C02_ADDRESS_R);	//发送从机地址，读写位为1，表示即将读取
	MyI2C_ReceiveAck();					//接收应答
	Data = MyI2C_ReceiveByte();			//接收指定寄存器的数据
	MyI2C_SendAck(1);					//发送应答，给从机非应答，终止从机的数据输出
	MyI2C_Stop();						//I2C终止
	
	return Data;
}
