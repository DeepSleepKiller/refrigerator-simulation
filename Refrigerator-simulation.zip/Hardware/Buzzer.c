#include "stm32f10x.h"                  // Device header
#include "Buzzer.h"
#include "Key.h"
#include "Timer.h"
/**
  * 函    数：蜂鸣器初始化
  * 参    数：无
  * 返 回 值：无
  */
void Buzzer_Init(Buzzer_state_t* state)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);		//开启GPIOB的时钟
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);						//将PB12引脚初始化为推挽输出
	
	/*设置GPIO初始化后的默认电平*/
	GPIO_SetBits(GPIOB, GPIO_Pin_12);							//设置PB12引脚为高电平
	
	*state = BUZZER_STATE_IDLE;									//初始化状态机
}

/**
  * 函    数：蜂鸣器开启
  * 参    数：无
  * 返 回 值：无
  */
void Buzzer_ON(void)
{
	GPIO_ResetBits(GPIOB, GPIO_Pin_12);		//设置PB12引脚为低电平
}

/**
  * 函    数：蜂鸣器关闭
  * 参    数：无
  * 返 回 值：无
  */
void Buzzer_OFF(void)
{
	GPIO_SetBits(GPIOB, GPIO_Pin_12);		//设置PB12引脚为高电平
}

/**
  * 函    数：蜂鸣器状态翻转
  * 参    数：无
  * 返 回 值：无
  */
void Buzzer_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_12) == 0)		//获取输出寄存器的状态，如果当前引脚输出低电平
	{
		GPIO_SetBits(GPIOB, GPIO_Pin_12);						//则设置PB12引脚为高电平
	}
	else														//否则，即当前引脚输出高电平
	{
		GPIO_ResetBits(GPIOB, GPIO_Pin_12);						//则设置PB12引脚为低电平
	}
}

/**
  * 函    数：蜂鸣器状态机
  * 参    数：蜂鸣器状态指针
  * 返 回 值：无
  * 说    明：检查蜂鸣器的状态，并在条件满足时跳转到下一状态，使用前需要先使用Buzzer_Init()函数初始化
  */

void Buzzer_Process(Buzzer_state_t* state)						
{
	static uint32_t  current_time;										//定义记录时间的变量，便于查询开门时间、控制鸣响间隙
	switch(*state)
	{
		case BUZZER_STATE_IDLE:
			if (Key_GetNum() == 0)										//空闲状态，通过门开启转换到另一个状态
			{
				current_time = Timer_Get_System_tick_ms();		
				*state = BUZZER_STATE_START_WAIT;				
			}
			break;
		case BUZZER_STATE_START_WAIT:
			if (Timer_Get_System_tick_ms() - current_time > 5000)
			{
				current_time = Timer_Get_System_tick_ms();
				*state = BUZZER_STATE_FLASH;
			}
			else if (Key_GetNum() == 1)
			{
				*state = BUZZER_STATE_IDLE;
				
			}				
			break;
		
		case BUZZER_STATE_FLASH:
			
			if(Key_GetNum() == 1)
			{
				Buzzer_OFF();
				*state = BUZZER_STATE_IDLE;
			}
			else if (Key_GetNum() == 0)
			{
				if (Timer_Get_System_tick_ms() - current_time > 1000)
				{
					Buzzer_Turn();
					current_time = Timer_Get_System_tick_ms();
				}

			}				
		default:
            break;
	}

	
}


