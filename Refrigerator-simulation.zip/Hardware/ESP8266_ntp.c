#include "stm32f10x.h"                  // Device header
#include "esp8266_ntp.h"				//第147行设置WiFi名称和密码
#include "Serial.h"
#include "string.h"
#include "Delay.h"
#include "Timer.h"

static uint32_t lastEpoch = 0;

static uint32_t lastHead = 0;

/* 等待指定关键字出现在接收缓冲区，超时返回 1 */
static uint8_t WaitAck(uint8_t *key, uint32_t timeoutMs)
{
    uint32_t t = 0;
    while(t < timeoutMs)
    {
        uint8_t* rxBuf = Serial_GetRxBuf();
        // 检查是否包含关键字或者"ERROR"
        if(strstr((char*)rxBuf, (char*)key) || strstr((char*)rxBuf, "ERROR"))
            return 0;
        Delay_ms(1); 
        t++;
    }
    return 1;   // 超时
}


/* 发送 AT 并等待关键字 */
static uint8_t SendAT_Chek(uint8_t *cmd, uint8_t *ack, uint32_t to)
{
    Serial_ClearRx();
    Serial_SendString(cmd);
    return WaitAck(ack, to);
}

///* 把 "+CIPSNTPTIME:: 2025-09-07 14:32:18" 解析成 6 个数，再转 Unix 时间戳 */
//static void ParseSNTP(void)
//{
//	char* pp = strstr((char*)Serial_GetRxBuf(), "+CIPSNTPTIME:");
//    uint8_t* p = (uint8_t*) pp;
//    if(!p) return;
//    uint16_t y,m,d,h,mi,s;
//    sscanf((char*)p, "+CIPSNTPTIME: %hu-%hu-%hu %hu:%hu:%hu", &y,&m,&d,&h,&mi,&s);
//    /* 简易 epoch 计算，2033 年前够用 */
//    u32 days = (y-1970)*365 + (y-1969)/4;
//    static const u16 mdays[12] = {0,31,59,90,120,151,181,212,243,273,304,334};
//    days += mdays[m-1] + d - 1;
//    if(m>2 && ((y%4==0 && y%100!=0)||y%400==0)) days++;
//    lastEpoch = days*86400 + h*3600 + mi*60 + s;
//}
/* 解析 +CIPSNTPTIME:Thu Sep 11 05:50:25 2025 */
void ParseSNTP(void)
{
    const char *head = strstr((char *)Serial_GetRxBuf(), "+CIPSNTPTIME:");
    /* 指向冒号后第一个字符 */

    if (!head) 
	{
		lastEpoch = 1; 
		return;
	}
	
	head += 17;
	lastHead = (uint32_t)head;


    char monthStr[4] = {0};
    uint16_t day, year, hour, min, sec;

    /* 读 6 个字段：星期(丢弃) 月 日 时:分:秒 年 */
	int n = sscanf(head, "%3s %hu %hu:%hu:%hu %hu",
                monthStr, &day, &hour, &min, &sec, &year);
	
    if (n != 6) 
	{
		lastEpoch = day+10; 
		return;          /* 解析失败直接退出 */
	}

	

    /* 把英文月名转数字 */
    static const char *monName[12] = {"Jan","Feb","Mar","Apr","May","Jun",
                                      "Jul","Aug","Sep","Oct","Nov","Dec"};
    uint16_t month = 0;
    for (uint16_t i = 0; i < 12; i++) {
        if (strncasecmp(monthStr, monName[i], 3) == 0) {
            month = i + 1;
            break;
        }
    }
    if (month == 0)
	{
		lastEpoch = 3;
		return;      /* 月名异常 */
		
	}		

    /*----- 计算 Y 年 M 月 D 日 到 1970-01-01 的总天数 -----*/
    uint32_t days = 0;

    /* 1) 整年累加 */
    for (uint16_t y = 1970; y < year; y++)
        days += ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)) ? 366 : 365;

    /* 2) 当月之前整月累加 */
    static const uint16_t monTab[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    for (uint16_t m = 1; m < month; m++) {
        days += monTab[m - 1];
        /* 闰年 2 月 */
        if (m == 2 && ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)))
            days++;
    }

    /* 3) 当月天数 */
    days += day - 1;

    /*----- 合成 UTC 秒 -----*/
    lastEpoch = days * 86400UL + hour * 3600 + min * 60 + sec - 8 * 60 * 60;
}

/*----------------------------------------------------------
* 主函数一次性调用即可
*----------------------------------------------------------*/
uint8_t ESP8266_InitAndGetTime(void)
{
	

    /* 0. 模块握手 */
    if(SendAT_Chek("AT\r\n", "OK", 500))          return 1;
    /* 1. 重启 */
    if(SendAT_Chek("AT+RST\r\n", "OK", 1500))  return 2;
	
    Delay_ms(500);

	
    /* 2. Station 模式 */
    if(SendAT_Chek("AT+CWMODE=1\r\n", "OK", 500)) return 3;
    /* 3. 关闭回显，方便解析 */
    if(SendAT_Chek("ATE0\r\n", "OK", 500))        return 4;
	

	
	
    /* 4. 连接路由器 */
    if(SendAT_Chek("AT+CWJAP=\"ESP8266Test\",\"85967777\"\r\n", "WIFI GOT IP", 6000)) //设置WiFi名称和密码
        return 5;
    /* 5. 配置 NTP：使能、东八区、服务器 */
    if(SendAT_Chek("AT+CIPSNTPCFG=1,8,\"ntp2.aliyun.com\"\r\n", "OK", 2000))
        return 6;
	Delay_ms(3000);
    /* 6. 立刻查询一次 */
    if(SendAT_Chek("AT+CIPSNTPTIME?\r\n", "OK", 5000))
        return 7;
    /* 7. 解析并保存 */
    ParseSNTP();
    return 0;
}

uint32_t GetLastEpoch(void)
{
	
	return lastEpoch; 
}

uint32_t GetLastHead(void)
{
	
	return lastHead; 
}
