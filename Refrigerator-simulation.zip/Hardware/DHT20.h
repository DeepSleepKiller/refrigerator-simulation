#ifndef __DHT20_H
#define __DHT20_H

/** 
  * 简  介： DHT20传输数据状态定义，定义传感器可能处于的各种状态
  */
typedef enum {
    DHT20_STATE_POWER_ON_WAIT,   // 上电后等待稳定
    DHT20_STATE_IDLE,            // 空闲，等待触发测量
    DHT20_STATE_TRIGGERED,       // 已发送触发测量命令
    DHT20_STATE_MEASURING_WAIT,  // 等待测量完成
    DHT20_STATE_READING,         // 正在读取数据
    DHT20_STATE_DATA_READY,      // 数据就绪，可供读取
    DHT20_STATE_ERROR            // 发生错误（如校验失败）
} DHT20_state_t;
/** 
  * 简  介： DHT20信息结构体，保存传感器的所有上下文信息
  */
typedef struct 
{
    DHT20_state_t  state;          // 当前状态
    uint32_t       wait_start_time; // 等待开始的时间戳（ms）
    uint32_t       wait_duration;   // 需要等待的时长（ms）
    float          temperature;     // 解析后的温度值
    float          humidity;        // 解析后的湿度值
    uint8_t        raw_data[7];     // 从传感器读取的原始数据
									// ... 可以添加其他信息，如I2C地址、错误计数器等
} DHT20_sensor_t;


uint8_t DHT20_GetState(void);
void DHT20_MeasureStart(void);
void DHT20_ReadDatas(uint8_t* Data, uint32_t* humid, uint32_t* temper);
_Bool DHT20_Read_Length_Datas(uint8_t* Data, uint8_t Length);
void DHT20_Data_Parse(DHT20_sensor_t* sensor);
void DHT20_Process(DHT20_sensor_t* sensor);
void DHT20_Init(DHT20_sensor_t* sensor);
void DHT20_Trigger_Measurement(DHT20_sensor_t* sensor);
_Bool DHT20_Get_Data(DHT20_sensor_t* sensor, float* temp, float* hum);
#endif
