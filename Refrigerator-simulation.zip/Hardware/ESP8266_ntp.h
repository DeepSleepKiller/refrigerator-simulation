#ifndef __ESP8266_NTP_H
#define __ESP8266_NTP_H

uint8_t ESP8266_InitAndGetTime(void);// 返回 0 成功，1 超时/Wi-Fi 失败

uint32_t GetLastEpoch(void);// 读取最近一次解析到的时间戳
uint32_t GetLastHead(void);//读取最近一次解析到的head
#endif
